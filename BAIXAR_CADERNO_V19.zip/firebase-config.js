/*
  Identificadores públicos do aplicativo Web no Firebase.
  A senha da proprietária e os códigos particulares nunca ficam neste arquivo.
*/
window.CADERNO_FIREBASE_CONFIG = {
  apiKey: 'AIzaSyB7T_tvZ_bDnbyrewJLos5VEG2mUSDUUcI',
  authDomain: 'caderno-especial.firebaseapp.com',
  projectId: 'caderno-especial',
  storageBucket: 'caderno-especial.firebasestorage.app',
  messagingSenderId: '528326331600',
  appId: '1:528326331600:web:d4ef972b1c7b231f3c62d5'
};

/*
  Endereço opcional de uma função protegida para leitura de escrita manual e
  resumos on-line. Nunca coloque uma chave secreta neste arquivo público.
  Sem esse endereço, resumo, tópicos e infográfico continuam funcionando
  localmente; somente a conversão da escrita manual em texto fica pendente.
*/
window.CADERNO_AI_ENDPOINT = '';
